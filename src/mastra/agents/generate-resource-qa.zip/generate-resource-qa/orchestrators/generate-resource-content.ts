import { ResourcePlanSchema, countQuestions } from '@/lib/resource/schemas'
import type { BnccSkill, PedagogicalPhase, ResourcePlan } from '@/lib/resource/schemas'
import { parseBnccCode, yearToPhase } from '@/lib/resource/bncc-parser'
import { getBnccSkillByCode } from '@/lib/bncc/services/bncc-service'
import { qaArchitectAgent } from '../architect/architect'
import { buildQaArchitectPrompt } from '../architect/prompts'
import { qaArtisanAgent } from '../artisan/artisan'
import { buildQaArtisanPrompt } from '../artisan/prompts'
import { RESOURCE_ARTISAN_RULES } from '../artisan/artisan-skills'
import { QA_COMPONENT_CATALOG } from '../shared/component-catalog'
import { MultiSkillGenerationMapSchema } from '../shared/schemas'
import { RESOURCE_OUTPUT_CONTRACT } from '../shared/skills'
import { AdaptiveLayoutEngine } from '@/lib/resource/adaptive-layout-engine'

const DEFAULT_QUESTION_COUNT: Record<PedagogicalPhase, number> = {
  phase_1: 2,
  phase_2: 3,
  phase_3: 4,
  phase_4: 5,
  phase_5: 6,
}

const ARTISAN_SKILLS = [
  QA_COMPONENT_CATALOG,
  RESOURCE_ARTISAN_RULES,
  RESOURCE_OUTPUT_CONTRACT,
].join('\n\n')

export async function generateResourceQaContent(
  bnccCodes: string[],
  questionCount?: number,
): Promise<ResourcePlan> {
  const codes = bnccCodes.slice(0, 5)
  const skillsData = await Promise.all(codes.map(code => getBnccSkillByCode(code)))
  const validSkills = skillsData.filter(s => !!s) as BnccSkill[]
  
  if (validSkills.length === 0) throw new Error('Nenhuma habilidade válida fornecida.')
  
  const mainSkill = validSkills[0]
  const phase = yearToPhase(parseBnccCode(mainSkill.code).year)
  const resolvedQuestionCount = questionCount || (DEFAULT_QUESTION_COUNT[phase] * validSkills.length)

  console.log(`[generate-qa] START codes=${codes.join(',')} questionCount=${resolvedQuestionCount} phase=${phase}`)

  console.log('[generate-qa] → QA Architect (Planning)')
  const architectResult = await qaArchitectAgent.generate(
    buildQaArchitectPrompt(validSkills.map(s => ({
      bnccCode: s.code,
      bnccDescription: s.description,
      bnccSubject: s.subject?.name || '',
      bnccGrade: s.grade?.name || '',
      pedagogicalExplanation: s.pedagogicalExplanation || '',
      curriculumGuidance: s.curriculumGuidance || '',
    })))
  )

  const pedagogicalReport = architectResult.text
  console.log('[generate-qa] Architect finished')

  console.log('[generate-qa] → QA Artisan (Writing)')
  const draftResult = await qaArtisanAgent.generate(
    buildQaArtisanPrompt({
      skills: validSkills,
      bnccMetadata: parseBnccCode(mainSkill.code),
      phase,
      questionCount: resolvedQuestionCount,
      pedagogicalReport,
      skillsBlock: ARTISAN_SKILLS,
    }),
    { structuredOutput: { schema: ResourcePlanSchema } },
  )

  const draft = draftResult.object
  
  console.log('[generate-qa] DONE → adaptive layout engine')
  const { plan: finalPlan } = await AdaptiveLayoutEngine.process(draft, { phase, subject: 'multi' })
  return finalPlan
}
