export const QA_COMPONENT_CATALOG = `
# COMPONENTES PERMITIDOS (APENAS QUESTÕES)

Você deve usar EXCLUSIVAMENTE os componentes de questão abaixo. É PROIBIDO o uso de caixas de texto (tip_box, concept_box), prosas ou blocos narrativos.

## QUESTÕES
- multiple_choice: Questão de múltipla escolha. Use distratores plausíveis.
- true_false: Lista de afirmações para V ou F.
- matching: Colunas para relacionar (deve ter leftItems e rightItems).
- fill_blank: Texto com lacunas. Use apenas se o contexto for rico.
- ordering: Ordenação de eventos ou conceitos.
- open_short: Resposta curta (2-3 linhas).
- open_long: Resposta longa/dissertativa (5-8 linhas).
- comprehension: Questão focada em interpretação de um pequeno texto contido no enunciado.
- reasoning: Questão que exige lógica ou análise de causa/consequência.
- creation: Atividade prática ou produção final do aluno.

## ESTRUTURA (OBRIGATÓRIO)
- page_header: Cabeçalho da página (um por página).
- page_footer: Rodapé da página (um por página).
- activity_intro: Use APENAS no início de blocos de questões para dar o comando geral, se necessário.
`;
