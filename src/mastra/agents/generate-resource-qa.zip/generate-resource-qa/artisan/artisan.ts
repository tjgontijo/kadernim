import { Agent } from '@mastra/core/agent'

function resolveGenerateResourceModel() {
  return `openai/${process.env.GENERATE_RESOURCE_MODEL || process.env.LESSON_PLAN_MODEL || 'gpt-4o'}`
}

export const qaArtisanAgent = new Agent({
  id: 'qa-artisan-agent',
  name: 'QA Artisan',
  instructions: 'Você é o Master Artisan. Sua missão é escrever questões de alta qualidade pedagógica, ricas em contexto e 100% focadas na avaliação do aluno.',
  model: resolveGenerateResourceModel(),
})
