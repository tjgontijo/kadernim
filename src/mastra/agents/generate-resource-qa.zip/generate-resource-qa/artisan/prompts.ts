import type { PedagogicalPhase } from '@/lib/resource/schemas'
import { QA_COMPONENT_CATALOG } from '../shared/component-catalog'

export function buildQaArtisanPrompt(input: {
  skills: Array<any>
  bnccMetadata: any
  phase: PedagogicalPhase
  questionCount: number
  pedagogicalReport: string
  skillsBlock: string
}) {
  const { skills, phase, questionCount, pedagogicalReport } = input

  const fullPedagogicalContext = skills.map(s => `
### Habilidade: ${s.code}
- Descrição: ${s.description}
- Explicação Pedagógica: ${s.pedagogicalExplanation || 'N/A'}
- Orientações Curriculares: ${s.curriculumGuidance || 'N/A'}
`).join('\n')

  return [
    input.skillsBlock,
    '',
    '# CONTEXTO PEDAGÓGICO BRUTO (BNCC)',
    fullPedagogicalContext,
    '',
    '# RELATÓRIO DO ARQUITETO (PLANEJAMENTO)',
    pedagogicalReport,
    '',
    QA_COMPONENT_CATALOG,
    '',
    '# TAREFA: GERAR LISTA DE QUESTÕES DE ALTA FIDELIDADE',
    `Você deve gerar EXATAMENTE ${questionCount} questões para a fase ${phase}.`,
    '',
    '## REGRAS DE OURO:',
    '1. APENAS QUESTÕES: É terminantemente proibido o uso de blocos de texto isolados (reading_box, story_block, tip_box, etc.).',
    '2. ENUNCIADOS RICOS: Para evitar espaços vazios na página e garantir profundidade, cada questão deve ter um enunciado bem contextualizado usando os dados pedagógicos acima.',
    '3. DISTRIBUIÇÃO: Garanta que todas as habilidades solicitadas sejam cobertas.',
    '4. FORMATAÇÃO: Cada página deve ter entre 2 a 4 questões, dependendo da complexidade, para manter a folha cheia e organizada.',
    '',
    '# Formato de saída',
    '{',
    '  "title": string,',
    '  "skill": { "code": "MULTI", "description": "Lista de Exercícios Multi-Habilidade" },',
    '  "pages": [{ "pageNumber": number, "components": [...] }],',
    '  "teacherGuide": { ... }',
    '}',
  ].join('\n')
}
