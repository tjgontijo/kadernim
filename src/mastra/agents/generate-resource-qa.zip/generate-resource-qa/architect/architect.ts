import { Agent } from '@mastra/core/agent'

function resolveGenerateResourceModel() {
  return `openai/${process.env.GENERATE_RESOURCE_MODEL || process.env.LESSON_PLAN_MODEL || 'gpt-4o'}`
}

export const qaArchitectAgent = new Agent({
  id: 'qa-architect-agent',
  name: 'QA Architect',
  instructions:
    'Você é um Especialista em Currículo e BNCC. Sua tarefa é analisar as habilidades fornecidas e criar um RELATÓRIO DE PLANEJAMENTO PEDAGÓGICO em Markdown. Este relatório deve detalhar: 1. Objetivos centrais, 2. Relações entre as habilidades, 3. Conceitos-chave e 4. Sugestões de como cobrar esses temas em questões.',
  model: resolveGenerateResourceModel(),
})
