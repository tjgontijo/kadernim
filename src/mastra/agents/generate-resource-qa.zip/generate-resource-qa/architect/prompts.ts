export function buildQaArchitectPrompt(skills: Array<{
  bnccCode: string
  bnccDescription: string
  bnccSubject: string
  bnccGrade: string
  pedagogicalExplanation?: string
  curriculumGuidance?: string
}>): string {
  const skillsContext = skills.map((p, i) => `
### HABILIDADE ${i + 1} (${p.bnccCode})
- Componente: ${p.bnccSubject}
- Ano: ${p.bnccGrade}
- Descrição BNCC: ${p.bnccDescription}
${p.pedagogicalExplanation ? `- Explicação Pedagógica: ${p.pedagogicalExplanation}` : ''}
${p.curriculumGuidance ? `- Orientação Curricular: ${p.curriculumGuidance}` : ''}
`).join('\n')

  return [
    '# MAPEAMENTO PEDAGÓGICO MULTI-HABILIDADE (CONTRATO Q&A)',
    'Você é o Multi-Skill Pedagogical Mapper. Sua função é receber dados de até 5 habilidades da BNCC e transformar isso em um mapa estruturado (MultiSkillGenerationMapSchema).',
    '',
    '## DADOS DAS HABILIDADES',
    skillsContext,
    '',
    '## INSTRUÇÕES DE MAPEAMENTO',
    '1. Para CADA habilidade no objeto `skills`, preencha o `SkillGenerationMapSchema` individual.',
    '2. No campo `crossSkillRelations`, identifique pontos de contato entre as habilidades fornecidas (Ex: Como a habilidade X de História conversa com a habilidade Y de Geografia).',
    '3. No campo `globalMustInclude`, defina temas transversais ou termos que devem permear todo o material de questões.',
    '',
    'FOCO TOTAL EM QUESTÕES: O mapeamento deve priorizar como essas habilidades podem ser cobradas em exercícios de diversos níveis cognitivos.',
  ].join('\n')
}
