# Níveis de Consciência — Eugene Schwartz aplicado ao Kadernim

Os 5 níveis definem *onde a professora está mentalmente* antes de ver nosso conteúdo.
Cada nível exige uma abordagem diferente — falar para o nível errado é invisível ou repele.

---

## Nível 1 — Inconsciente do Problema

### Quem são
Professoras que não identificam o tempo gasto em planejamento como um problema *solucionável*. Vivem a sobrecarga como "normal da profissão" — "sempre foi assim, sempre vai ser". Geralmente professoras em início de carreira (ainda não acumularam a exaustão) ou veteranas que normalizaram a sobrecarga como parte da identidade profissional.

### O que pensam
- "É difícil, mas faz parte. Todo mundo passa por isso."
- "Ser professora é assim mesmo."
- "Não tem como ser diferente."
- "Fazer material próprio é o que une teoria e prática."

### Volume estimado no público
~30% das professoras ativas no Instagram

### Objetivo do conteúdo
**Não vender nada.** Criar identificação. Fazer ela comentar "isso sou eu" e começar a seguir o perfil.

### O que funciona

**Formato:** Carrossel de identificação, meme, Reel de "um dia na vida"
**Gatilho:** Humor + validação emocional + "você não está sozinha"
**Nunca:** mencionar produto, preço, solução

### Exemplos de conteúdo

**Carrossel:** "A semana típica de uma professora de educação infantil (em horas)"
- Slide 1: gancho visual — relógio ou calendário
- Slides 2–6: segunda (busca atividade), quarta (monta apresentação), sexta (formata para imprimir), domingo tarde (planeja), domingo noite (escreve planos)
- Slide final: "Isso não é falta de organização. É a realidade. Salva se você se identificou."

**Carrossel:** "Coisas que só professora de educação infantil entende"
- Lista de situações cotidianas precisas e engraçadas
- Nenhuma menção ao produto
- CTA: "Marca uma colega que vai se identificar"

---

## Nível 2 — Consciente do Problema

### Quem são
Professoras que já *sabem* que perdem muito tempo planejando e que o material gratuito é de qualidade inconsistente. Sabem que o problema existe, mas não sabem que existe uma solução acessível e específica para elas.

### O que pensam
- "Queria ter mais tempo."
- "Esses materiais do Pinterest são uma bagunça."
- "Preciso de algo melhor, mas não sei o quê."
- "Não consigo terminar o planejamento sem perder horas."

### Volume estimado no público
~35% das professoras ativas no Instagram

### Objetivo do conteúdo
**Amplificar a dor e nomear o custo real.** Criar urgência sem ainda apresentar a solução. Aprofundar o problema para que ela sinta que precisa resolver.

### O que funciona

**Formato:** Carrossel educativo, stories com enquete, carrossel de "o que ninguém calcula"
**Gatilho:** Amplificação da dor + custo oculto do problema (tempo, dinheiro, energia mental)
**Nunca:** vender antes de construir conexão

### Exemplos de conteúdo

**Carrossel:** "Quanto tempo você realmente gasta preparando material por semana?"
- Slide 1: pergunta provocativa
- Slide 2: destrincha cada tarefa com tempo médio (busca no Pinterest: 2h30, formatar: 1h15, etc.)
- Slide 3: total — "~8h por semana"
- Slide 4: "Em um semestre são 170 horas. Isso é 7 dias inteiros da sua vida."
- Slide 5: "Não é falta de organização. É falta de sistema."
- Slide final: "Salva pra mostrar pra quem acha que professora tem muito tempo livre."

**Carrossel:** "O problema real com buscar material de graça no Pinterest"
- Desmonta o mito do "gratuito que funciona"
- Não apresenta solução — só amplifica por que o processo atual dói

**Story com enquete:**
- "Você planeja aula no domingo?" → Sim / Não
- Próximo story: "X% de vocês responderam Sim. Isso não deveria ser normal."

---

## Nível 3 — Consciente da Solução

### Quem são
Professoras que já sabem que existem plataformas de materiais prontos, assinaturas pedagógicas, geradores de plano de aula. Já usaram ou pesquisaram alternativas — Nova Escola, grupos pagos, kits no Hotmart. Estão avaliando opções mas decepcionadas com o que tentaram.

### O que pensam
- "Existem vários serviços assim. Qual presta de verdade?"
- "Já gastei dinheiro em coisa que não funcionou."
- "Quero ver antes de comprar."
- "Será que é diferente do que já tentei?"

### Volume estimado no público
~20% das professoras ativas no Instagram

### Objetivo do conteúdo
**Mostrar o diferencial de forma concreta.** Ela já sabe que soluções existem — precisa ver por que o Kadernim é diferente do que já tentou.

### O que funciona

**Formato:** Carrossel de comparativo, demonstração do produto, carrossel "antes e depois"
**Gatilho:** Diferenciação concreta + prova de qualidade + transparência
**Nunca:** prometer o que não entrega ou fazer comparativo vago

### Exemplos de conteúdo

**Carrossel:** "Por que as professoras que usavam Pinterest vieram para o Kadernim"
- Slide 1: "Você já tentou se organizar com Pinterest/grupos/Nova Escola?"
- Slides 2–4: o que cada solução entrega e onde para
- Slide 5: "O Kadernim não substitui isso — ele organiza o que você já precisava em um lugar só"
- Slides 6–7: mostra a biblioteca, o gerador de plano, a comunidade
- Slide final: CTA com garantia

**Carrossel:** "Como é o material do Kadernim na prática"
- Mostrar prints/fotos reais dos PDFs prontos
- Mostrar o plano de aula gerado (antes: prompt simples / depois: plano completo)
- "Isso é o que uma professora de 2º ano recebeu em 23 segundos"

**Carrossel:** "Diferença entre material genérico e material feito para sua turma"
- Comparativo visual sem atacar concorrentes pelo nome
- Foco: o Kadernim foi criado especificamente para Ed. Infantil e Fundamental I

---

## Nível 4 — Consciente do Produto

### Quem são
Professoras que já conhecem o Kadernim especificamente. Viram um post, foram indicadas por colega, salvaram o perfil. Sabem da proposta, mas ainda não assinaram. Em fase de avaliação: "será que vale?"

### O que pensam
- "Parece bom, mas R$ 27 todo mês... será que vou usar?"
- "E se não gostar?"
- "Preciso ver mais material antes de decidir."
- "Quanto tempo vou economizar de verdade?"

### Volume estimado no público
~10% das professoras ativas no Instagram

### Objetivo do conteúdo
**Quebrar objeções uma a uma.** Ela já quer — falta remover o medo da decisão errada.

### O que funciona

**Formato:** Carrossel de objeções, depoimentos detalhados, demonstração com resultado real
**Gatilho:** Quebra de objeção específica + garantia + urgência de calendário
**Nunca:** ignorar o medo de "jogar dinheiro fora"

### Exemplos de conteúdo

**Carrossel:** "Suas dúvidas sobre o Kadernim respondidas"
- Slide 1: "Já recebi essas perguntas várias vezes. Vou responder todas."
- Slide 2: "E se eu não usar? → Novo material toda semana cria o hábito de voltar. E temos garantia de 7 dias."
- Slide 3: "A coordenação vai aceitar o plano de IA? → Você revisa antes de entregar. A IA poupa o esforço braçal, você mantém o controle."
- Slide 4: "Vale R$ 27/mês? → Você decide na primeira semana. Se não valer, devolvemos tudo."
- Slide 5: "É difícil de usar? → Você digita o tema e a série. A IA faz o resto em 23 segundos."
- Slide final: CTA direto + link na bio

**Carrossel:** "O que [nome da professora] economizou na primeira semana"
- Depoimento real estruturado: quem é, qual escola, qual turma, quanto tempo economizou, o que achou
- Específico e verificável — não genérico

---

## Nível 5 — Mais Consciente (Pronto para Comprar)

### Quem são
A professora que já decidiu assinar — está esperando o momento certo ou um último empurrão. Pode ter clicado no link e saído. Está esperando o salário cair, querendo ver mais um depoimento, ou simplesmente procrastinando a decisão.

### O que pensam
- "Vou assinar essa semana."
- "Só quero ter certeza que vale."
- "Preciso de um motivo final para clicar."

### Volume estimado no público
~5% das professoras ativas no Instagram

### Objetivo do conteúdo
**Fricção zero para a conversão.** Remover qualquer obstáculo entre ela e o clique.

### O que funciona

**Formato:** Story de CTA direto, carrossel curto de "por que agora", post de resultado imediato
**Gatilho:** Urgência real + remoção de fricção + reforço de decisão
**Nunca:** criar urgência falsa (queima o relacionamento com quem já acompanha)

### Exemplos de conteúdo

**Story:** "Você já salvou esse perfil, mas ainda não testou. Por quê não hoje?"
- Link direto no story
- "7 dias para testar. Se não gostar, devolvo. Sem burocracia."

**Carrossel curto (3 slides):** "Por que assinar agora e não depois"
- Slide 1: "Setembro começa em [X] dias. Planejado ou correndo?"
- Slide 2: Mostra o que está disponível agora na plataforma (materiais de setembro)
- Slide 3: CTA + garantia

**Post simples:** "Entrei hoje no Kadernim pela primeira vez. Em 40 minutos já tinha o planejamento da semana pronto." (depoimento fresh de aluna nova)

---

## Distribuição recomendada de conteúdo por nível

| Nível | % de posts | Objetivo |
|---|---|---|
| 1 — Inconsciente | 25% | Alcance orgânico, novos seguidores |
| 2 — Consciente do problema | 30% | Engajamento profundo, salvamentos |
| 3 — Consciente da solução | 20% | Consideração, visita ao perfil/site |
| 4 — Consciente do produto | 15% | Conversão, quebra de objeções |
| 5 — Pronto para comprar | 10% | Fechamento, CTA direto |

> **Nota**: A maioria do público está nos Níveis 1 e 2. Conteúdo para esses níveis tem maior alcance orgânico. Conteúdo para Nível 4–5 tem menor alcance mas maior taxa de conversão direta.
