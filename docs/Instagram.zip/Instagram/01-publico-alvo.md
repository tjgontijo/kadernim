# Público-Alvo: Professoras de Ed. Infantil e Fundamental I

## Dados demográficos

- **Universo total**: ~2,35M professores na educação básica no Brasil (Censo Escolar 2024)
- **Feminino**: 96,2% na Ed. Infantil, 94,2% pré-escola — profissão essencialmente feminina
- **Faixa etária central**: 30–48 anos (maior concentração em 40–49 anos, 35,2%)
- **Rede pública municipal**: 72,5% das matrículas de Ed. Infantil, 69,5% do Fundamental I
- **Renda**: R$ 2.600–R$ 4.942/mês para graduadas na rede pública (Classe C/D)
- **Piso 2024**: R$ 4.867,77 para 40h (na prática, muitas ganham menos por regime parcial ou vínculos temporários)
- **~460.000 professores** trabalham em mais de uma escola para complementar renda

## Endereçabilidade no Instagram

- 1,3–1,5M professoras ativas no Instagram (estimativa)
- Segmento Ed. Infantil + Fundamental I específico: **600.000–800.000 professoras ativas**
- Brasil: 141M usuários no Instagram (66,2% da população)

## Rotina cotidiana

**Dia de semana:**
- Acorda 5h30–6h, enfrenta transporte público
- Na escola das 7h às 12h/13h com turmas de 20–30 crianças (frequentemente sem auxiliar)
- HTPC/hora-atividade consumida por reuniões burocráticas
- Volta para casa, filhos, tarefas domésticas

**Fins de semana:**
- Sábado: início do planejamento, pesquisa de material
- **Domingo à noite: planejamento ativo** — maior janela de receptividade para o produto
- Planeja no domingo, madrugada ou nos intervalos da escola

**Comportamento digital:**
- Recebe mensagens de pais no WhatsApp às 22h e responde
- Pesquisa atividades no Pinterest, salva no Instagram, monta PDF em casa
- Imprime na impressora pessoal quando a escola não tem papel/tinta

## Como usa o Instagram

**Três momentos de uso:**
1. **Intervalos da semana** (recreio, espera do transporte) — scroll rápido, salvamento de atividades
2. **Noite 20h–22h** — Reels e stories mais longos após o jantar
3. **Fins de semana** (sábado manhã e domingo) — busca ativa de material e planejamento

**Comportamentos chave:**
- **Salvam muito**: 77% dos brasileiros salvam posts — professoras salvam atividades para imprimir
- **Compartilham muito**: 84% compartilham — mandam para grupos de WhatsApp da escola
- **Compram pelo Instagram**: 73% já compraram algo descoberto na plataforma

**Por que seguem perfis educacionais:**
1. Inspiração rápida para atividades da semana
2. Formação continuada informal sem pagar curso caro
3. Validação e pertencimento ("outras passam pelo mesmo")
4. Salvar referências para datas comemorativas
5. Descobrir produtos e serviços

## Onde buscam material hoje

| Fonte | Como usam | Problema |
|---|---|---|
| Pinterest | Busca visual de atividades prontas | 2h para achar 1 atividade ok; muito conteúdo em inglês |
| Instagram | Descoberta passiva, inspiração | Qualidade irregular, não organizado |
| Nova Escola | Planos BNCC gratuitos | Genérico demais, interface pouco prática no celular |
| Grupos de WhatsApp | Troca de PDFs entre colegas | Qualidade irregular, dependência de quem posta |
| Facebook | Páginas como "Cantinho Pedagógico da Sil" (555K) | Público 35-50 anos, conteúdo menos atualizado |
| Google + blogs | Busca "atividade de matemática para imprimir grátis" | Tempo de garimpagem alto |
| Hotmart avulso | Kits anuais por tema | Paga caro e o material decepciona |

## Perfis de referência no nicho

| Perfil | Seguidores | Posicionamento |
|---|---|---|
| @educacao.infantil.oficial | ~386K | Atividades prontas, lúdicas |
| @professoramichelle | ~353K | Aulas lúdicas, Ed. Infantil |
| @professoraalbamarilia | ~361K | Pedagoga formadora |
| @varalde.ideias | crescimento acelerado | Relatórios pedagógicos, Ed. Infantil |
| @novaescola | grande base | Institucional, BNCC, autoridade |

## Hashtags do nicho

**Alto volume:**
`#educacaoinfantil` `#pedagogia` `#escola` `#professorasdobrasil` `#atividadespedagogicas`

**Nicho segmentado (maior engajamento relativo):**
`#serprofessora` `#pedagogiaporamor` `#bncc` `#alfabetizacao` `#aprenderbrincando` `#desenvolvimentoinfantil` `#psicopedagogia`

**Sazonais (picos de busca):**
`#voltaasaulas` `#diadadocente` `#festajunina` `#pascoa` `#diadadama`

## Horários estratégicos para postar

| Dia | Horário | Por quê |
|---|---|---|
| Terça | 11h–16h | Pico de engajamento para conteúdo educacional |
| Quarta | 12h–15h | Alto engajamento no intervalo |
| Quinta | 10h–12h | Bom alcance orgânico |
| Domingo | 19h–21h | Professoras planejando, mais receptivas ao produto |
| Segunda | 7h–8h | Sentem urgência de não ter planejado direito |
