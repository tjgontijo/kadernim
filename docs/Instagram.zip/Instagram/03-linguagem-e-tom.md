# Linguagem, Vocabulário e Tom de Comunicação

## Como elas falam sobre o dia a dia

### Sobre as crianças
- "Minha turma", "minhas crianças", "meus pequenos", "meus bebês" (mesmo para 4–5 anos)
- "A turminha tá linda hoje"
- "O fulano não parou um segundo"

### Sobre o trabalho
- "Fiz o planejamento na madrugada"
- "Domingo virei professora de novo"
- "Saí da escola com a cabeça explodindo"
- "Imprimi tudo em casa porque a escola não tem papel"
- "Passei o fim de semana montando material"
- "A coordenação pediu mais um relatório"
- "BNCC me mata" / "como alinho isso à BNCC?"
- "Deu branco" (quando não sabe o que fazer numa situação)
- "Atividade pra preencher tempo não é o meu estilo"

### Sobre identidade profissional
- "Ser professora é um chamado"
- "Não aguento mais, mas amo o que faço"
- "Ninguém valoriza quem mais importa"
- "Professora não é babá" (resistência forte a essa percepção)

### Sobre produtos e compras
- "Já tentei vários e nenhum prestou"
- "Esse material parece feito de verdade por professora"
- "Comprei um curso e não vi nada diferente"
- "Paguei e nunca mais abri"

---

## Palavras que ressoam (usar)

| Palavra/Frase | Por quê funciona |
|---|---|
| "Pronto para imprimir" | Remove fricção mental — ela não precisa fazer nada mais |
| "Você merece um domingo livre" | Ataca o desejo mais profundo e imediato |
| "Feito por professoras, para professoras" | Identidade compartilhada, credibilidade |
| "Sua turma vai amar" | Desloca o foco para o impacto nas crianças |
| "Sem stress no planejamento" | Nomeia o alívio de forma concreta |
| "Alinhado à BNCC" | Remove o medo de erro institucional |
| "Sem garimpar" | Nomeia exatamente a dor do processo atual |
| "Semana mais leve" | Concreto e imediato, não abstrato |
| "Comunidade", "juntas", "troca" | Pertencimento como benefício real |
| "Prática", "simples", "rápida" | Contrasta com a complexidade atual |

## Palavras que afastam (evitar)

| Palavra/Frase | Por quê afasta |
|---|---|
| "Revolucionário" / "disruptivo" | Soa corporativo e distante da realidade |
| "Plataforma" | Frio e técnico, sem conexão emocional |
| "IA generativa" | Assusta, parece complicado e técnico |
| "Metodologia baseada em evidências" | Jargão acadêmico que parece crítica velada à prática atual |
| "Conteúdo premium" | Não ressoa com quem se sente mal paga |
| "Invista em você" | Desgastado por infoprodutos, soa como pressão |
| "Transformação digital" | Abstrato e corporativo |
| "Potencialize sua prática" | Vago demais, sem benefício concreto |

---

## Tom de comunicação que funciona

### O arquétipo: a colega experiente e bem-humorada

Falar como uma professora que resolveu o problema e quer compartilhar com as colegas — não como uma marca, não como uma autoridade acadêmica.

**Características do tom:**
- **Empático antes de propositivo**: primeiro reconhece a dor ("Você chegou em casa com 3 atividades para montar para amanhã..."), depois oferece a solução
- **Concreto, não abstrato**: não "melhora sua prática pedagógica", mas "aqui está a atividade de quarta-feira pronta para imprimir"
- **Humor leve sobre a rotina caótica**: memes e piadas sobre "domingo de professora" têm engajamento altíssimo — identificação imediata
- **Orgulho da profissão**: reforça que ser professora é importante e que ela merece ferramentas de qualidade — cria reciprocidade emocional
- **Sem julgamento**: nunca implica que ela está fazendo errado; o problema é sistêmico, não dela

### Exemplos de tom certo vs. errado

**Errado:** "Otimize seu tempo de planejamento com nossa plataforma de IA educacional."
**Certo:** "Você passou o domingo planejando de novo. A gente sabe. Isso tem que acabar."

**Errado:** "Invista no seu desenvolvimento profissional com materiais premium."
**Certo:** "248 atividades prontas para imprimir. Você abre, baixa, imprime. Sem editar nada."

**Errado:** "Nossa metodologia baseada em evidências garante alinhamento à BNCC."
**Certo:** "O plano de aula sai alinhado à BNCC em 23 segundos. Você confere, ajusta se quiser, e pronto."

---

## Estrutura de copy que converte

```
1. GANCHO — abre com a dor específica no primeiro segundo
   "Você chegou em casa às 17h depois de um dia caótico e ainda tem 3 atividades para montar para amanhã?"

2. VALIDAÇÃO — mostra que entende antes de vender
   "A gente sabe o quanto é pesado. Você não deveria ter que fazer isso sozinha."

3. SOLUÇÃO CONCRETA — benefícios, não features
   "No Kadernim, você encontra +248 materiais prontos para imprimir e gera seu plano de aula em 23 segundos, alinhado à BNCC."

4. PROVA — número ou depoimento
   "Mais de X professoras já recuperaram o domingo delas."

5. CTA SEM PRESSÃO — frição zero, risco zero
   "Teste por 7 dias. Se não valer, devolvemos cada centavo."
```
