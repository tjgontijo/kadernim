# Dores, Desejos e Objeções do Público

## Dores primárias (as que tiram o sono)

### 1. Tempo — o recurso que nunca sobra
A dupla/tripla jornada (escola + casa + planejamento) consome 100% da energia.
- ~8h/semana gastas em busca, formatação e planejamento do zero
- 170h por semestre fora de sala em preparação não remunerada
- 36% dizem que tecnologia *aumenta* o tempo de planejamento quando mal implementada

### 2. Planejamento como fonte de angústia
A BNCC criou uma camada burocrática nova: não basta planejar, precisa documentar objetivos de aprendizagem, habilidades, competências.
- Professoras experientes que planejavam "de cabeça" agora se sentem perdidas com a nomenclatura
- "Como alinho isso à BNCC?" aparece diariamente em grupos de WhatsApp

### 3. Falta de recursos materiais
Na escola pública, imprimir pode ser um drama (sem papel, sem tinta, impressora quebrada).
- A professora imprime em casa, de bolso
- Pagar R$ 27 por material bom custa menos que a soma dos meses imprimindo materiais ruins sozinha

### 4. Cobranças crescentes com salário estagnado
- Relatórios pedagógicos, reuniões com família, adaptação para alunos com necessidades especiais, documentação fotográfica — tudo sem hora extra
- 21,5% avaliam sua saúde mental como ruim ou muito ruim (Nova Escola, 2022)
- 60,1% relatam episódios intensos de ansiedade

## Dores secundárias (que influenciam a decisão de compra)

- **Insegurança técnica**: medo de usar o gerador de IA e não saber o que está fazendo
- **Medo de julgamento**: "o plano vai parecer genérico/copiado pela coordenação?"
- **Isolamento profissional**: muitas trabalham em escolas pequenas sem troca entre pares
- **Desatualização**: sentem pressão para dominar BNCC, IA, tecnologias — mas não têm tempo para estudar

## O que elas sonham

**Para a carreira:**
- Reconhecimento: "que as pessoas entendam o quanto é difícil o que a gente faz"
- Ter material de qualidade sem criar tudo do zero
- Sala organizada com materiais bonitos e funcionais
- Ser vista como profissional competente pela coordenação e pelos pais

**Para a vida pessoal:**
- **Domingo livre** — o desejo mais imediato e concreto (o argumento mais forte do Kadernim)
- Tempo para os filhos e para si mesma
- Poder dizer "estou preparada para segunda-feira" na sexta à noite
- Menos culpa — a culpa por "não fazer o suficiente" é constante e corrosiva

## Frustrações com soluções que já tentaram

| Solução | Frustração |
|---|---|
| Nova Escola | "Bom, mas genérico. Elaborado demais para o cotidiano corrido." |
| Pinterest | "Passo 2h procurando e acho muita coisa ruim ou em inglês." |
| ChatGPT genérico | "Plano cheio de termos da BNCC errados, tenho que revisar tudo." |
| Grupos de WhatsApp | "Qualidade irregular, nunca sei se o arquivo presta." |
| Cursos online | "Aprendi teoria mas na hora de montar a aula continuei na mesma." |
| Kits Hotmart | "Paguei R$97 por um kit 'do ano todo' e era básico demais." |

## Objeções de compra e como quebrar

### Objeção 1 — "Não tenho dinheiro" / "É caro"
A professora pública ganhando R$3.000 pensa antes de qualquer gasto novo.

**Como quebrar:**
- Âncora comparativa: "menos que um lanche por semana"
- Mostrar o custo de tempo: 1h de planejamento salvo/semana = 4h/mês ≈ R$50 de hora de trabalho
- Garantia de 7 dias — remove o risco financeiro completamente

---

### Objeção 2 — "Já acho de graça no Pinterest/Instagram"
A maior objeção. O hábito de pegar gratuitamente está profundamente enraizado.

**Como quebrar:**
- O argumento não é "gratuito vs. pago" — é **qualidade + organização + tempo**
- "Você passa 2h procurando no Pinterest para achar 1 atividade ok. Aqui você acha 248 em 5 minutos, todas prontas para imprimir."
- Mostrar o custo *real* do grátis (tempo perdido, qualidade ruim, materiais desalinhados)

---

### Objeção 3 — "Não sei se o material presta"
Professoras são céticas com conteúdo genérico. Querem saber se foi feito por quem entende de sala de aula real.

**Como quebrar:**
- Depoimentos em vídeo de professoras reais com detalhes específicos
- Mostrar amostras reais dos materiais antes da compra
- Evidenciar a autoria: quem criou, qual experiência em sala

---

### Objeção 4 — "Vai ser complicado de usar"
Medo da curva de aprendizado, especialmente para o gerador de IA.

**Como quebrar:**
- Demonstração em 30 segundos do processo completo
- Enfatizar "23 segundos" e mostrar literalmente o fluxo inteiro
- "Você digita o tema e a série — a IA faz o resto"

---

### Objeção 5 — "Vou pagar e esquecer"
Muitas já assinaram serviços digitais que nunca usaram.

**Como quebrar:**
- Mostrar que novo material entra toda semana (razão para voltar)
- Comunidade ativa que cria engajamento contínuo
- Email de onboarding com primeiro uso guiado

---

### Objeção 6 — "A coordenação não vai aceitar o plano gerado por IA"
Medo real de ser questionada pela gestão escolar.

**Como quebrar:**
- Posicionar a IA como *assistente*, não substituta: "você aprova, você personaliza — a IA só poupa o esforço braçal"
- Mostrar planos gerados que parecem profissionais e alinhados à BNCC
- Depoimentos de professoras que já apresentaram para coordenação

## O que faz comprar (gatilhos de conversão)

1. **Depoimento de professora igual a ela** — vídeo de 30–60s de uma colega com contexto específico converte mais que qualquer copy
2. **Visualizar o resultado antes** — ver o PDF pronto, o plano gerado em 23s, material impresso na escola
3. **Autoridade contextualizada** — não "especialista", mas "professora com 10 anos de sala de aula que criou isso para resolver exatamente o que você passa"
4. **Garantia de risco zero** — 7 dias de devolução remove a barreira psicológica
5. **Urgência do calendário escolar** — "nova turma começa segunda-feira", "setembro começa em 3 semanas"
6. **Comunidade** — "Mais de X professoras já usam" + comunidade ativa = prova social + FOMO
