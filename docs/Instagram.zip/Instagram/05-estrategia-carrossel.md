# Estratégia de Carrossel — Formato Principal

O carrossel é o formato prioritário porque: alto salvamento (algoritmo favorece), permite profundidade sem depender de câmera, gera compartilhamento em grupos de WhatsApp, e funciona nos horários de uso passivo (intervalos, noite).

---

## Anatomia de um carrossel que converte

```
Slide 1 — GANCHO (faz parar o scroll)
Slide 2–3 — PROBLEMA (aprofunda a dor)
Slide 4–6 — DESENVOLVIMENTO (educa, compara, demonstra)
Slide 7–8 — PROVA ou SOLUÇÃO (credibilidade)
Slide 9 — CTA suave (ou forte, dependendo do nível de consciência)
```

**Regras inegociáveis:**
- Slide 1 decide se ela vai virar — tem que ser irresistível
- Cada slide tem que justificar o próximo (não pode ser autocontido)
- Texto curto por slide: máximo 2–3 linhas no corpo, 1 frase de transição
- Visual simples e limpo — professoras leem no celular em 30s de intervalo
- Último slide: sempre tem uma ação clara (salvar, comentar, link na bio)

---

## Tipos de carrossel por nível de consciência

### Tipo A — "Identificação" (Nível 1–2)
**Objetivo:** viralização e novos seguidores
**Estrutura:** rotina descrita com precisão + validação emocional
**CTA:** "Salva se você se identificou" / "Marca uma colega"
**Métrica-alvo:** salvamentos + compartilhamentos

---

### Tipo B — "Custo oculto" (Nível 2)
**Objetivo:** amplificar a dor e criar urgência de resolução
**Estrutura:** cálculo de horas/dinheiro + "você não percebeu que..."
**CTA:** "Salva pra mostrar pra quem acha que professora tem muito tempo livre"
**Métrica-alvo:** salvamentos + comentários de identificação

---

### Tipo C — "Educativo com gancho de produto" (Nível 2–3)
**Objetivo:** dar valor real + plantar semente da solução
**Estrutura:** ensina algo útil nos slides 1–7, slide 8 mostra como o produto acelera isso
**CTA:** "Link na bio para ver como funciona"
**Métrica-alvo:** salvamentos + cliques no perfil

---

### Tipo D — "Demonstração" (Nível 3–4)
**Objetivo:** mostrar o produto funcionando sem vídeo
**Estrutura:** prints do produto real com contexto e resultado
**CTA:** "Teste por 7 dias — link na bio"
**Métrica-alvo:** cliques no link + conversões

---

### Tipo E — "Quebra de objeção" (Nível 4)
**Objetivo:** remover o último obstáculo para a compra
**Estrutura:** pergunta → resposta direta → prova → garantia
**CTA:** CTA direto com garantia
**Métrica-alvo:** conversões diretas

---

## Banco de ideias — 40 carrosseis prontos para produzir

### NÍVEL 1 — Identificação (10 ideias)

1. **"A semana típica de uma professora de educação infantil (em horas)"**
   - Mapeia cada dia com o que a professora faz FORA da sala de aula
   - Fecha com total: ~8h/semana, 170h/semestre

2. **"Coisas que só professora de Ed. Infantil entende"**
   - Lista de situações cotidianas precisas: a impressora que nunca funciona, o relatório pedido na quinta para entregar na sexta, o pai que manda áudio às 22h
   - Nenhuma menção ao produto — puro entretenimento/identificação

3. **"Como é o domingo de uma professora vs. o que as pessoas acham"**
   - Lado A: o que as pessoas acham (descanso, família, lazer)
   - Lado B: o que realmente é (planejamento, formatação, impressão)

4. **"Tipos de professora na segunda-feira de manhã"**
   - Personagens diferentes baseados na realidade
   - Humor leve, reconhecível, compartilhável

5. **"A evolução do planejamento de aula (de 1990 a hoje)"**
   - Mostra como as cobranças aumentaram sem que o tempo disponível aumentasse
   - Fecha com "a exigência aumentou. O domingo continuou sendo 24h."

6. **"Por que professora chega em casa cansada mesmo quando foi 'um dia tranquilo'"**
   - Lista o custo cognitivo invisível da profissão
   - Sem CTA — só validação

7. **"O que a professora faz nas 'férias' que ninguém vê"**
   - Formação obrigatória, planejamento do ano, compra de material, decoração da sala
   - "Férias" entre aspas — puro reconhecimento

8. **"O que ninguém te disse antes de virar professora"**
   - Lista de realidades da profissão que a faculdade não ensina
   - Tom afetivo, sem cinismo

9. **"A professora de educação infantil e seus 8 trabalhos simultâneos"**
   - Educadora, psicóloga, enfermeira, decoradora, fotógrafa, secretária, relatório pedagógico, WhatsApp de pais
   - "E ainda tem gente que pergunta por que você está cansada."

10. **"O ciclo semanal que nunca para"**
    - Segunda → busca atividade → Quarta → monta → Sexta → formata → Domingo → planeja do zero → Segunda de novo
    - Visual de ciclo/loop que não tem saída

---

### NÍVEL 2 — Custo oculto (10 ideias)

11. **"Você calculou quanto tempo gasta planejando por semana?"**
    - Destrincha cada tarefa com tempo médio real
    - Fecha com total e o que esse tempo poderia ser

12. **"O problema real com buscar material de graça no Pinterest"**
    - Não é o gratuito que é ruim — é o processo que drena
    - 2h para achar 1 atividade razoável, em inglês, sem BNCC, fora do contexto da turma

13. **"Quanto você gasta de bolso com a sua escola pública"**
    - Impressão em casa, papel, tinta, material de decoração, lanche para festinha
    - "E ainda dizem que professora tem bom salário e estabilidade."

14. **"Sua saúde mental e o planejamento de domingo"**
    - Dados sobre burnout docente + como o ciclo de preparação contribui
    - Tom de cuidado, não de alarme

15. **"O que 170 horas poderiam ser"**
    - 170h = 7 dias inteiros = 4 meses de domingos = horas com os filhos que não voltam
    - Emocional, sem apelação

16. **"Por que grupos de WhatsApp de professoras não resolvem o problema"**
    - Qualidade irregular, dependência de quem posta, não há organização, arquivo expira
    - Não critica quem usa — valida a solução criativa e mostra o limite dela

17. **"O custo invisível de montar tudo do zero"**
    - Energia mental, decisão fatigue, qualidade das aulas que ficam comprometidas quando você planejou correndo
    - "Não é falta de dedicação. É falta de recurso."

18. **"Por que a professora experiente ainda perde horas planejando"**
    - A BNCC mudou as regras; o que funcionava antes não funciona igual agora
    - A experiência não resolve o problema de tempo

19. **"O material que você comprou no Hotmart e nunca abriu"**
    - Reconhecimento de uma frustração comum — sem julgamento
    - "A culpa não é sua. O produto prometeu mais do que entregou."

20. **"Você está pagando para trabalhar"**
    - Calcula: horas de domingo + papel + tinta + material comprado = quanto custa manter a qualidade das aulas com o próprio dinheiro
    - Dado concreto, impactante

---

### NÍVEL 3 — Consciente da solução (8 ideias)

21. **"O que muda quando você tem 248 atividades organizadas em um lugar só"**
    - Antes: processo de busca manual
    - Depois: processo com biblioteca organizada
    - Sem nomear o produto explicitamente nos primeiros slides

22. **"Por que professoras que usavam só Pinterest migraram para plataformas específicas"**
    - Jornada de decisão real (identificação → frustração → busca → decisão)
    - Slide final apresenta o Kadernim como opção

23. **"A diferença entre plano de aula genérico e plano feito para sua série e tema"**
    - Lado a lado: plano genérico vs. plano específico
    - Mostra o gerador de IA como solução

24. **"Como gerar um plano de aula alinhado à BNCC em menos de 1 minuto"**
    - Carrossel tutorial — ensina o processo com prints
    - Slide 7–8: "Isso é exatamente o que o Kadernim faz automaticamente"

25. **"5 materiais de setembro que toda professora de fundamental I precisa"**
    - Conteúdo de valor real (os materiais ou categorias de materiais)
    - Slide final: "Esses e mais 248 estão no Kadernim — link na bio"

26. **"O que uma plataforma de materiais pedagógicos precisa ter para valer o preço"**
    - Critérios objetivos (alinhamento à BNCC, atualização semanal, comunidade, qualidade de impressão)
    - Slide final: checklist do Kadernim vs. o que ela provavelmente já tentou

27. **"Por que IA para plano de aula só funciona quando é específica para Ed. Infantil"**
    - ChatGPT genérico vs. IA treinada com contexto pedagógico específico
    - Introduz o diferencial do gerador do Kadernim

28. **"3 formas de economizar tempo no planejamento (e por que 2 delas não funcionam sozinhas)"**
    - Forma 1: organizar melhor o que já tem (funciona parcialmente)
    - Forma 2: usar Pinterest de forma sistemática (funciona parcialmente)
    - Forma 3: ter tudo pronto em um lugar específico (resolve de verdade)

---

### NÍVEL 4 — Consciente do produto (7 ideias)

29. **"Suas dúvidas sobre o Kadernim respondidas"**
    - Cada slide responde uma objeção real (preço, uso, IA, garantia, qualidade)
    - Tom direto e honesto — não defensivo

30. **"O que você ganha nas primeiras 48h no Kadernim"**
    - Onboarding visual: passo 1, 2, 3 com resultado concreto
    - "Você sai com o planejamento da semana pronto"

31. **"Depoimento: [Nome] economizou X horas na primeira semana"**
    - Estrutura: quem é + qual turma + qual problema tinha + o que usou + resultado específico
    - Real, com detalhes, verificável

32. **"A garantia de 7 dias na prática: o que acontece se você pedir reembolso"**
    - Transparência total sobre o processo
    - Remove o medo de "cair em golpe" — constrói confiança

33. **"Kadernim vs. fazer do zero: o que você ganha (e o que não perde)"**
    - Comparativo honesto — não pretende substituir a criatividade da professora
    - Posiciona como ferramenta, não substituto

34. **"Como professoras usam o Kadernim no dia a dia (rotina real)"**
    - Segunda: baixa a atividade do tema da semana
    - Quarta: gera plano de aula para a sexta
    - Domingo: 30min para fechar o planejamento da semana
    - "É assim que parece."

35. **"R$ 27/mês: o que você recebe exatamente"**
    - Lista detalhada e concreta de tudo que está incluído
    - Comparativo de valor: "menos que uma pizza, mais que qualquer curso de organização que você já fez"

---

### NÍVEL 5 — Pronto para comprar (5 ideias)

36. **"Setembro começa em X dias. Você já tem o planejamento?"**
    - Urgência real de calendário escolar
    - Mostra o que está disponível para setembro na plataforma
    - CTA: assina hoje, planeja esta semana

37. **"Entrei hoje no Kadernim: primeiras impressões"**
    - Perspectiva de usuária nova — autêntico, não polido demais
    - Remove o medo do desconhecido

38. **"Por que eu demorei 3 meses para assinar (e o que mudou)"**
    - Jornada real de uma professora que tinha todas as objeções e assinou
    - Identifica o momento de decisão: "o domingo que foi o último"

39. **"Você salvou esse perfil. Por que não testou ainda?"**
    - Interpela diretamente quem está no perfil há tempo
    - "7 dias de garantia. O risco é nosso, não seu."

40. **"O que você perde esperando mais uma semana"**
    - Urgência real baseada no calendário escolar
    - Não é ameaça — é matemática: "mais um domingo de planejamento do zero"

---

## Cadência semanal recomendada

| Semana | Segunda | Quarta | Sexta |
|---|---|---|---|
| 1 | Identificação (N1) | Custo oculto (N2) | Demonstração (N3) |
| 2 | Identificação (N1) | Educativo (N2-3) | Quebra de objeção (N4) |
| 3 | Custo oculto (N2) | Solução (N3) | Depoimento (N4) |
| 4 | Identificação (N1) | Educativo (N2-3) | CTA direto (N5) |

**Frequência:** 3 carrosseis/semana como base
**Stories:** diários (enquetes, bastidores, CTAs rápidos)
**Reels de IA** (opcional): 1 por mês mostrando o gerador em ação — alto impacto de demonstração

---

## Checklist de qualidade por carrossel

Antes de publicar, verificar:

- [ ] Slide 1 faz parar o scroll? (teste: cobrir o texto — a imagem/layout chama atenção?)
- [ ] O texto do Slide 1 promete algo que os próximos slides entregam?
- [ ] Cada slide leva para o próximo? (nenhum é autocontido)
- [ ] Usa linguagem do público? (sem jargão, com expressões reais)
- [ ] Tem alguma palavra que afasta? (ver lista em 03-linguagem-e-tom.md)
- [ ] O CTA final é claro e tem fricção baixa?
- [ ] O visual é legível em tela pequena de celular?
- [ ] Está no nível de consciência certo para o que quer atingir?
