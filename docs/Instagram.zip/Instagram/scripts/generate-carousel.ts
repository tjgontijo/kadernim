import { chromium } from 'playwright';
import * as path from 'path';
import * as fs from 'fs';

async function gerarCarrossel(caminhoHtml: string) {
  const htmlPath = path.resolve(process.cwd(), caminhoHtml);
  
  if (!fs.existsSync(htmlPath)) {
    console.error(`Erro: Arquivo não encontrado em ${htmlPath}`);
    process.exit(1);
  }

  const baseDir = path.dirname(htmlPath);
  const outDir = path.join(baseDir, 'output');
  
  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
  }

  console.log(`\n📸 Iniciando exportação do carrossel: ${path.basename(baseDir)}`);

  const browser = await chromium.launch();
  const context = await browser.newContext({
    viewport: { width: 1080, height: 1350 },
    deviceScaleFactor: 2 // Renderização 2x (retina) para máxima nitidez das fontes
  });
  const page = await context.newPage();

  await page.goto(`file://${htmlPath}`, { waitUntil: 'networkidle' });

  // Encontra os elementos .slide que possuem id "slide-X"
  const slidesLocator = page.locator('.slide[id^="slide-"]');
  const count = await slidesLocator.count();

  if (count === 0) {
    console.warn('   Nenhum slide encontrado! Certifique-se de que cada slide tem `class="slide"` e `id="slide-1"`, etc.');
  }

  for (let i = 0; i < count; i++) {
    const slide = slidesLocator.nth(i);
    const id = await slide.getAttribute('id');
    const numeral = id?.split('-')[1] || String(i + 1);
    const outFile = path.join(outDir, `slide-${numeral.padStart(2, '0')}.png`);
    
    await slide.screenshot({ path: outFile, type: 'png' });
    console.log(`✓  Gerado: slide-${numeral.padStart(2, '0')}.png`);
  }

  await browser.close();
  console.log(`\n✅ Sucesso! ${count} slides exportados para ${outDir}\n`);
}

const args = process.argv.slice(2);
if (args.length === 0) {
  console.log(`
Uso correto: 
  npx tsx docs/Instagram/scripts/generate-carousel.ts <caminho/do/slides.html>

Exemplo paramétrico:
  npx tsx docs/Instagram/scripts/generate-carousel.ts docs/Instagram/carrosseis/ciclo-semanal/slides.html
  `);
  process.exit(1);
}

gerarCarrossel(args[0]).catch((err) => {
  console.error("❌ Erro fatal ao exportar o carrossel:");
  console.error(err);
  process.exit(1);
});
