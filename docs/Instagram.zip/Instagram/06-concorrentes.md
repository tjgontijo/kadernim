# Contexto de Mercado e Concorrentes

## Tamanho do mercado

- EdTech Brasil 2024: **USD 5,41 bilhões** (projeção USD 14,64 bi até 2033, CAGR 11,7%)
- Brasil tem **68,93% das EdTechs da América Latina** ativas
- **83% dos professores brasileiros** já usam materiais digitais em sala (BlinkLearning/MEC)
- **56% dos professores** já usam IA em suas práticas (Talis 2024) — desses, **77% para gerar planos de aula ou atividades**

> A adoção de IA para planejamento já existe. O Kadernim está surfando uma onda em ascensão.

---

## Principais concorrentes

### Nova Escola — O Gigante Gratuito

**Posicionamento:** autoridade institucional, gratuita, alinhada ao MEC

**O que oferece:**
- +6.000 planos de aula gratuitos
- Cursos com certificação
- Ferramenta de planejamento via WhatsApp
- Conteúdo editorial de qualidade

**Fraqueza para o nosso público:**
- Muito ampla — pouco específica para Ed. Infantil no cotidiano
- Interface mais acadêmica, menos prática para imprimir no dia a dia
- Não tem geração de IA personalizada
- Não tem comunidade interativa

**Posição no funil:** Topo (professoras que buscam gratuitamente nunca "saem" da Nova Escola — mas ela não resolve o problema de tempo de forma sistêmica)

**Como o Kadernim se diferencia:** "A Nova Escola é ótima para formação. O Kadernim é para quando você tem 30 minutos para planejar a semana inteira."

---

### Comunidade Pedagógica — O concorrente mais direto

**Posicionamento:** comunidade + materiais prontos + suporte humanizado

**O que oferece:**
- Materiais temáticos (Moana, Turma da Mônica, etc.)
- Encontros ao vivo
- WhatsApp comunitário
- ~10.000 professoras assinantes

**Preço:** R$ 59,99/mês (ou R$ 599/ano) — o dobro do Kadernim

**Fraqueza:**
- Preço mais alto
- Sem gerador de IA para plano de aula
- Foco em material decorativo/temático mais do que funcional/pedagógico

**Como o Kadernim se diferencia:** Mesmo público-alvo, com preço ~55% menor e diferencial do gerador de IA. Argumento: "Tudo que a Comunidade Pedagógica oferece, e ainda gera seu plano de aula em 23 segundos — por R$ 27/mês."

---

### Teachy — A IA concorrente

**Posicionamento:** "Mais de 60 ferramentas de IA para professores"

**O que oferece:**
- Acesso a 1 milhão de materiais
- Modelo freemium (começa grátis, cobra em créditos/premium)
- Afirma ter atingido 5 milhões de professores

**Fraqueza para o nosso público:**
- Foco em Ensino Médio e Fundamental II também — menos especializado em Ed. Infantil
- Interface mais técnica e genérica
- Comunidade menos focada no nicho

**Como o Kadernim se diferencia:** "A IA do Teachy é genérica. A do Kadernim foi construída para Ed. Infantil e Fundamental I — especificidade que aparece no resultado."

---

### Pinterest / Nova Escola (gratuitos)

O maior "concorrente" não é uma plataforma paga — é o **hábito de buscar de graça**.

**A armadilha do posicionamento errado:** Não comparar com "gratuito vs. pago". Comparar com **custo de tempo**.

"Você 'economiza' R$ 27 e perde 8 horas. Ou você paga R$ 27 e recupera 8 horas toda semana."

---

## Implicações para o conteúdo

### Não mencionar concorrentes pelo nome
Nunca comparar diretamente. A diferenciação acontece mostrando o que o Kadernim entrega, não atacando o que os outros não entregam.

### Usar o tamanho do hábito gratuito a favor
O conteúdo de Nível 2 que desmonta o mito do "Pinterest resolve" não precisa mencionar alternativa — só precisa mostrar o custo real do processo atual.

### Posicionar a comunidade como vantagem não replicável
Ferramentas de IA genéricas não têm comunidade de professoras de Ed. Infantil. Esse é o diferencial menos copiável.
