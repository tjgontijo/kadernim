# Estratégia Instagram — Kadernim

Documentação de suporte para criação de conteúdo orgânico no Instagram.
Foco principal: **carrossel**. Reels apenas quando o impacto justificar (demonstração do produto com IA).

---

## Arquivos

| Arquivo | Conteúdo |
|---|---|
| [01-publico-alvo.md](01-publico-alvo.md) | Perfil demográfico, rotina, comportamento no Instagram, horários, hashtags, perfis de referência |
| [02-dores-desejos-objecoes.md](02-dores-desejos-objecoes.md) | Dores primárias e secundárias, sonhos, medos, frustrações com soluções atuais, como quebrar cada objeção |
| [03-linguagem-e-tom.md](03-linguagem-e-tom.md) | Vocabulário do público, palavras que ressoam vs. afastam, tom de comunicação, estrutura de copy que converte |
| [04-niveis-de-consciencia.md](04-niveis-de-consciencia.md) | Os 5 níveis de Eugene Schwartz aplicados ao público do Kadernim — quem são, o que pensam, o que publicar para cada nível |
| [05-estrategia-carrossel.md](05-estrategia-carrossel.md) | Anatomia do carrossel, 5 tipos por nível de consciência, banco de 40 ideias prontas, cadência semanal, checklist de qualidade |
| [06-concorrentes.md](06-concorrentes.md) | Nova Escola, Comunidade Pedagógica, Teachy, Pinterest — diferenciais e como abordar no conteúdo |

---

## Distribuição de conteúdo por nível de consciência

| Nível | % dos posts | Objetivo principal |
|---|---|---|
| 1 — Inconsciente do problema | 25% | Alcance orgânico, novos seguidores |
| 2 — Consciente do problema | 30% | Engajamento profundo, salvamentos |
| 3 — Consciente da solução | 20% | Consideração, visita ao perfil/site |
| 4 — Consciente do produto | 15% | Conversão, quebra de objeções |
| 5 — Pronto para comprar | 10% | Fechamento, CTA direto |

---

## Cadência semanal

3 carrosseis/semana + stories diários

| Semana | Segunda | Quarta | Sexta |
|---|---|---|---|
| 1 | Identificação (N1) | Custo oculto (N2) | Demonstração (N3) |
| 2 | Identificação (N1) | Educativo (N2-3) | Quebra de objeção (N4) |
| 3 | Custo oculto (N2) | Solução (N3) | Depoimento (N4) |
| 4 | Identificação (N1) | Educativo (N2-3) | CTA direto (N5) |

---

## Princípios de comunicação

1. **Empático antes de propositivo** — reconhece a dor antes de oferecer a solução
2. **Concreto, não abstrato** — "atividade de quarta-feira pronta para imprimir", não "melhora sua prática pedagógica"
3. **Tom de colega, não de marca** — como uma professora que resolveu o problema e quer compartilhar
4. **Nunca criar urgência falsa** — urgência real é o calendário escolar
5. **Salvamento e compartilhamento como meta** — conteúdo que vai para grupos de WhatsApp tem alcance multiplicado
