
// Desabilitar cache
export const dynamic = 'force-dynamic'
export const revalidate = 0

export default function RequestPage() {
  return (
    <div className="container mx-auto px-4 py-4">
      <p>Página de solicitações</p>
    </div>
  );
}
