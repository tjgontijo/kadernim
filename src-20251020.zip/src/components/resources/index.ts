// src/components/resources/index.ts
export { ResourcesFilters } from './resources-filters'
export { ResourcesGrid } from './resources-grid'
