import { randomBytes } from 'crypto'
import { prisma } from '@/lib/prisma'

const MAGIC_LINK_EXPIRATION_MINUTES = 20

export async function generateMagicLink(
  email: string,
  callbackURL: string = '/resources'
): Promise<string> {
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.NEXT_PUBLIC_BASE_URL

  if (!baseUrl) {
    throw new Error('Base URL não configurada para geração do magic link')
  }

  try {
    const token = randomBytes(32).toString('hex')
    const expiresAt = new Date(Date.now() + MAGIC_LINK_EXPIRATION_MINUTES * 60 * 1000)

    await prisma.verification.create({
      data: {
        identifier: email,
        value: token,
        expiresAt
      }
    })

    const magicLinkUrl = `${baseUrl}/api/v1/auth/magic-link/verify?token=${token}&callbackURL=${encodeURIComponent(callbackURL)}`

    console.log('[magic-link] Token gerado', {
      email,
      expiresAt: expiresAt.toISOString(),
      callbackURL,
      magicLinkUrl
    })

    return magicLinkUrl
  } catch (error) {
    console.error('[magic-link] Erro ao gerar magic link:', error)
    throw new Error('Falha ao gerar magic link')
  }
}
