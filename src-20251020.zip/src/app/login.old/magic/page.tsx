'use client'

import { useEffect, useState, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Image from 'next/image'
import { toast } from 'sonner'

function MagicLinkVerifyContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [status, setStatus] = useState<'verifying' | 'success' | 'error'>('verifying')
  const [errorMessage, setErrorMessage] = useState('')

  useEffect(() => {
    const verifyToken = async () => {
      const token = searchParams?.get('token')
      const callbackURL = searchParams?.get('callbackURL') || '/resources'

      if (!token) {
        setStatus('error')
        setErrorMessage('Token não encontrado')
        return
      }

      try {
        // Verifica o token usando o Better Auth
        const response = await fetch(`/api/v1/auth/magic-link/verify?token=${token}`, {
          method: 'GET',
          credentials: 'include'
        })

        if (response.ok) {
          setStatus('success')
          toast.success('Login realizado com sucesso!')
          
          // Aguarda um pouco para o usuário ver a mensagem
          setTimeout(() => {
            router.push(callbackURL)
          }, 1500)
        } else {
          const data = await response.json()
          setStatus('error')
          setErrorMessage(data.error || 'Token inválido ou expirado')
          toast.error('Erro ao fazer login')
        }
      } catch (error) {
        console.error('Erro ao verificar magic link:', error)
        setStatus('error')
        setErrorMessage('Erro ao processar o link de acesso')
        toast.error('Erro ao fazer login')
      }
    }

    verifyToken()
  }, [searchParams, router])

  return (
    <div className="flex min-h-screen items-center justify-center bg-white dark:bg-gray-900">
      <div className="w-full max-w-md px-4">
        <div className="py-8 px-4 sm:px-6 text-center">
          <div className="mb-6 flex justify-center">
            <Image 
              src="/images/system/logo_transparent.png" 
              alt="Kadernim Logo" 
              width={150} 
              height={150} 
              style={{ height: 'auto' }}
              priority
            />
          </div>

          {status === 'verifying' && (
            <div>
              <div className="mb-4 flex justify-center">
                <div className="h-12 w-12 animate-spin rounded-full border-4 border-indigo-600 border-t-transparent" />
              </div>
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                Verificando seu acesso...
              </h2>
              <p className="text-gray-600 dark:text-gray-400">
                Aguarde um momento
              </p>
            </div>
          )}

          {status === 'success' && (
            <div>
              <div className="mb-4 flex justify-center">
                <div className="h-12 w-12 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                  <svg className="h-6 w-6 text-green-600 dark:text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
              </div>
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                Login realizado com sucesso! ✨
              </h2>
              <p className="text-gray-600 dark:text-gray-400">
                Redirecionando você...
              </p>
            </div>
          )}

          {status === 'error' && (
            <div>
              <div className="mb-4 flex justify-center">
                <div className="h-12 w-12 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
                  <svg className="h-6 w-6 text-red-600 dark:text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </div>
              </div>
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                Erro ao fazer login
              </h2>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                {errorMessage}
              </p>
              <button
                onClick={() => router.push('/login')}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Voltar para o login
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default function MagicLinkVerifyPage() {
  return (
    <Suspense fallback={
      <div className="flex min-h-screen items-center justify-center bg-white dark:bg-gray-900">
        <div className="flex items-center justify-center">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-indigo-600 border-t-transparent" />
        </div>
      </div>
    }>
      <MagicLinkVerifyContent />
    </Suspense>
  )
}
